x= lambda a: a.isnumeric()
y=input("Enter the character:")
if x(y)==True:
    print("Numeric")
else:
    print("Not numeric")